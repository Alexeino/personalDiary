const express = require("express");
const bodyParser = require("body-parser");
const ejs = require("ejs");
// var posts = [];
const _ = require("lodash");
const mongoose = require('mongoose');
const app = express();

// Connecting to MongoDB DB Name = diaryDB

mongoose.connect("mongodb://localhost:27017/diaryDB", {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

// Making MongoDB Schema named diarySchema..

const diarySchema = new mongoose.Schema({

  postTitle: String,
  postContent: String

});

// Defining the Collection for the Database.. Collection Name = Posts..
const Post = mongoose.model("Post", diarySchema);



app.set('view engine', 'ejs');
const welcomeText = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quisque id diam vel quam elementum pulvinar etiam non. Lacus sed viverra tellus in hac habitasse platea dictumst vestibulum. In egestas erat imperdiet sed euismod. Cras semper auctor neque vitae. Libero justo laoreet sit amet cursus sit. Volutpat est velit egestas dui. Eget nunc lobortis mattis aliquam faucibus. Turpis egestas integer eget aliquet nibh praesent tristique magna. Lacus sed turpis tincidunt id aliquet risus feugiat in. Etiam non quam lacus suspendisse faucibus interdum posuere lorem. Tellus orci ac auctor augue mauris augue neque. Pretium viverra suspendisse potenti nullam ac tortor vitae."

app.use(bodyParser.urlencoded({
  extended: true
}));
app.use(express.static("public"));



app.get("/", function(req, res) {

  // Displaying All the Posts on the Home Page "/"... Using Model.find()...
  // Model Name = Post...
  Post.find({}, function(err, docs) {

    // All the returning Objects are saved into an array named docs (from callback) we later parse them.

    if (!err) {
      res.render("home", {
        welcomeText: welcomeText,
        posts: docs
      });
    } else {
      console.log(err);
    }

  });


});


// Compose Page Get method....

app.get("/compose", function(req, res) {
  res.render("compose");
});

// Compost POST Method
//name = postBody & post Title

app.post("/compose", function(req, res) {

  // Every time submit button is clicked a new Entry named post is added with mode Post...

  const post = new Post({
    postTitle: req.body.postTitle,
    postContent: req.body.postBody
  });

  post.save(function(err) {
    if (!err) {
      console.log("Saved Succesfully");
      res.redirect("/");
    } else {
      console.log("Error in saving Post Line 67");
    }
  });


});

// Setup Get method for Read More Substrings............

app.get("/post/:postTitle", function(req, res) {
  console.log(req.params.postTitle);

  Post.findOne({
    postTitle: req.params.postTitle
  }, function(err, doc) {
    if(!err){
      res.render("post",{
        title: doc.postTitle,
        content: doc.postContent
      });
    }else{
      console.log("Error at findOne() line 103");
    }

  });

});


// Starting Local Server at 3000;
app.listen(3000, function() {
  console.log("Server started at 3000");
});
